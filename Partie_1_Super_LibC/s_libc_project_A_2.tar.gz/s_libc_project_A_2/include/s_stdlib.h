#ifndef S_STDLIB_H
#define S_STDLIB_H

extern int s_atoi(const char *str);

#endif // S_STDLIB_H

