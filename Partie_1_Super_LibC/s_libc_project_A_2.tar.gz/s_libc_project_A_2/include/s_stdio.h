#ifndef S_STDIO_H
#define S_STDIO_H

extern int s_puts(const char *str);

#endif // S_STDIO_H

